import { useState } from "react";
import reactLogo from "./assets/react.svg";
import "./App.css";
import DivBy16 from "./components/DivBy16";

function App() {
  return (
    <>
      <DivBy16 />
    </>
  );
}

export default App;
