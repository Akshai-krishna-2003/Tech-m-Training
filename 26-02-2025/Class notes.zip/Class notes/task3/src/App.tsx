import StudList from "./components/StudList";

function App() {
  return (
    <>
      <StudList />
    </>
  );
}

export default App;
